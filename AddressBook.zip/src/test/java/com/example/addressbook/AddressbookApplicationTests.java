package com.example.addressbook;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AddressbookApplicationTests {

    @Test
    void contextLoads() {
    }

}
